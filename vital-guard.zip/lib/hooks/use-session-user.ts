'use client'

import { useEffect } from 'react'
import useSWR from 'swr'
import type { User } from '@supabase/supabase-js'
import { getSupabaseBrowserClient } from '@/lib/supabase/client'

const SESSION_USER_KEY = 'supabase-session-user'

async function fetchSessionUser(): Promise<User | null> {
  const { data } = await getSupabaseBrowserClient().auth.getUser()
  return data.user ?? null
}

export function useSessionUser() {
  const { data, isLoading, mutate } = useSWR(SESSION_USER_KEY, fetchSessionUser, {
    revalidateOnFocus: false,
  })

  useEffect(() => {
    const { data: listener } = getSupabaseBrowserClient().auth.onAuthStateChange((_event, session) => {
      mutate(session?.user ?? null, { revalidate: false })
    })
    return () => listener.subscription.unsubscribe()
  }, [mutate])

  return { user: data ?? null, isLoading }
}
