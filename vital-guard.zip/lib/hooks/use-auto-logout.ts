'use client'

import { useCallback, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { getSupabaseBrowserClient } from '@/lib/supabase/client'
import { useSessionUser } from '@/lib/hooks/use-session-user'

export const IDLE_TIMEOUT_MS = 15 * 60 * 1000
const CHECK_INTERVAL_MS = 15 * 1000
const ACTIVITY_THROTTLE_MS = 1000
const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'] as const

export function useAutoLogout() {
  const router = useRouter()
  const { user } = useSessionUser()
  const lastActivityRef = useRef(Date.now())
  const loggingOutRef = useRef(false)

  const logout = useCallback(
    async (reason?: 'inactividad') => {
      if (loggingOutRef.current) return
      loggingOutRef.current = true
      await getSupabaseBrowserClient().auth.signOut()
      router.replace(reason ? `/login?motivo=${reason}` : '/login')
      loggingOutRef.current = false
    },
    [router],
  )

  useEffect(() => {
    if (!user) return

    lastActivityRef.current = Date.now()

    function markActivity() {
      const now = Date.now()
      if (now - lastActivityRef.current > ACTIVITY_THROTTLE_MS) lastActivityRef.current = now
    }

    function checkIdle() {
      if (Date.now() - lastActivityRef.current >= IDLE_TIMEOUT_MS) logout('inactividad')
    }

    ACTIVITY_EVENTS.forEach((event) => window.addEventListener(event, markActivity, { passive: true }))
    document.addEventListener('visibilitychange', checkIdle)
    const interval = window.setInterval(checkIdle, CHECK_INTERVAL_MS)

    return () => {
      ACTIVITY_EVENTS.forEach((event) => window.removeEventListener(event, markActivity))
      document.removeEventListener('visibilitychange', checkIdle)
      window.clearInterval(interval)
    }
  }, [user, logout])

  return { handleLogout: () => logout() }
}
