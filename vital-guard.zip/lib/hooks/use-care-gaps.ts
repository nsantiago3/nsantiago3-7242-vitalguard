'use client'

import useSWR from 'swr'
import { getSupabaseBrowserClient } from '@/lib/supabase/client'
import { loadCareGaps, type CareGapsResult } from '@/lib/data/care-gaps'
import { useSessionUser } from './use-session-user'

export function useCareGaps(initial: CareGapsResult) {
  const { user } = useSessionUser()

  const { data } = useSWR(
    user ? ['care-gaps', user.id] : null,
    () => loadCareGaps(getSupabaseBrowserClient()),
    { fallbackData: initial, revalidateOnMount: true, revalidateOnFocus: false },
  )

  return data ?? initial
}
