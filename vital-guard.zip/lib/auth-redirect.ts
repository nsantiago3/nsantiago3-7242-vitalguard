const PRODUCTION_HOSTS = ['vitalguard.app', 'www.vitalguard.app', 'vitalguardhealth.app', 'www.vitalguardhealth.app']
const CANONICAL_ORIGIN = 'https://vitalguard.app'

// Los dominios de produccion usan siempre el dominio canonico. En el preview de v0
// el enlace de confirmacion debe pasar por el proxy de redireccion de v0.
export function getAuthCallbackUrl() {
  const { hostname, origin } = window.location

  if (PRODUCTION_HOSTS.includes(hostname)) return `${CANONICAL_ORIGIN}/auth/callback`

  return process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ?? `${origin}/auth/callback`
}
