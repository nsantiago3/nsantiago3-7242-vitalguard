export const DEMO_TODAY = '2026-10-04'

export type HistoryEvent = { at: string; actor: string; action: string }

export type TaskStatus = 'pending' | 'scheduled' | 'closed'

export type Task = {
  id: string
  score: number
  title: string
  patient: string
  age: number
  measure: string
  offset: number
  evidence: string
  owner: string
  reason: string
  status: TaskStatus
  history: HistoryEvent[]
}

const SYSTEM = 'VitalGuard'

const t = (
  id: string,
  score: number,
  title: string,
  patient: string,
  age: number,
  measure: string,
  offset: number,
  evidence: string,
  owner: string,
  reason: string,
  detectedAt: string,
  status: TaskStatus = 'pending',
): Task => ({
  id,
  score,
  title,
  patient,
  age,
  measure,
  offset,
  evidence,
  owner,
  reason,
  status,
  history: [
    { at: detectedAt, actor: SYSTEM, action: 'Brecha detectada a partir de evidencia clínica y de reclamaciones' },
    { at: detectedAt, actor: SYSTEM, action: `Prioridad calculada: ${score}` },
    { at: detectedAt, actor: SYSTEM, action: `Asignada a ${owner}` },
  ],
})

export const SEED_TASKS: Task[] = [
  t('t1', 91, 'Ordenar HbA1c y agendar revisión', 'María Fernanda López', 58, 'HEDIS GSD · HbA1c', -12, 'FHIR + Claims', 'Enf. Carla Juárez', 'Medida de peso triple, paciente con HbA1c previa fuera de rango y fecha vencida hace 12 días.', '2026-09-10 08:14'),
  t('t2', 88, 'Agendar mamografía de cernimiento', 'María Fernanda López', 58, 'HEDIS BCS-E', -20, 'Claims', 'Coord. Diego Fuentes', 'Sin mamografía registrada en 27 meses; la ventana de medición cierra este año.', '2026-09-02 09:41'),
  t('t3', 85, 'Llamada de seguimiento post-alta', 'Jorge Alberto Méndez', 67, 'HEDIS TRC · 7 días', -2, 'FHIR + Seguimiento', 'Coord. Diego Fuentes', 'Alta hospitalaria hace 9 días sin contacto de seguimiento documentado.', '2026-09-28 16:05'),
  t('t4', 80, 'Control de presión arterial', 'Rosa Elena Paredes', 71, 'HEDIS CBP', -5, 'FHIR', 'Enf. Carla Juárez', 'Última lectura sistólica por encima de 140 mmHg y sin control repetido.', '2026-09-24 10:20'),
  t('t5', 78, 'Examen de ojo diabético', 'Carlos Andrés Rojas', 63, 'HEDIS EED', 0, 'Claims', 'Coord. Diego Fuentes', 'Vence hoy; sin examen retinal en el año de medición.', '2026-09-30 11:02'),
  t('t6', 74, 'Entregar kit FIT de cernimiento colorrectal', 'Luisa Marina Ortega', 62, 'HEDIS COL', 2, 'Claims + Laboratorio', 'Enf. Carla Juárez', 'Elegible por edad, sin cernimiento vigente y con preferencia por prueba en casa.', '2026-09-26 13:47'),
  t('t7', 70, 'Solicitar evaluación de función renal', 'Pedro Pablo Salas', 69, 'HEDIS KED', 4, 'FHIR', 'Enf. Carla Juárez', 'Diabetes tipo 2 sin eGFR ni uACR en el período.', '2026-09-27 08:30'),
  t('t8', 66, 'Revisar prescripción de estatina', 'Ana Beatriz Vega', 65, 'HEDIS SPC', 6, 'Farmacia + Claims', 'Dra. Lucía Ramírez', 'Enfermedad cardiovascular establecida sin estatina de intensidad alta.', '2026-09-29 15:12'),
  t('t9', 60, 'Reconciliar medicación post-alta', 'Héctor Luis Navarro', 72, 'HEDIS TRC', 8, 'FHIR + Seguimiento', 'Coord. Diego Fuentes', 'Reconciliación pendiente dentro de los 30 días posteriores al alta.', '2026-10-01 09:00'),
  t('t10', 55, 'Mamografía de cernimiento confirmada', 'Elena Torres', 56, 'HEDIS BCS-E', 9, 'Claims', 'Coord. Diego Fuentes', 'Cita ya programada; confirmar asistencia y registrar resultado.', '2026-09-20 12:33', 'scheduled'),
  t('t11', 52, 'Ordenar HbA1c trimestral', 'Miguel Ángel Cruz', 60, 'HEDIS GSD · HbA1c', 11, 'FHIR + Claims', 'Enf. Carla Juárez', 'Última HbA1c hace 5 meses; próximo control próximo a vencer.', '2026-09-25 17:18'),
  t('t12', 45, 'Orientar colonoscopia de cernimiento', 'Gloria Patricia Díaz', 66, 'HEDIS COL', 15, 'Claims', 'Dra. Lucía Ramírez', 'Colonoscopia previa vencida; requiere derivación a gastroenterología.', '2026-09-18 10:55'),
  t('t13', 38, 'Control de presión arterial de rutina', 'Tomás Herrera', 59, 'HEDIS CBP', 28, 'FHIR', 'Enf. Carla Juárez', 'Hipertensión controlada; mantener lectura documentada antes de fin de año.', '2026-09-15 14:40'),
]
