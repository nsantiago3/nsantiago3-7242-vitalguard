export type Plan = {
  id: string
  name: string
  members: number
  open: number
  closed: number
  stars: number
  prevStars: number
}

export type Measure = {
  code: string
  name: string
  weight: number
  rate: number
  threshold: number
  stars: number
}

export type CareGap = {
  id: string
  memberName: string
  memberId: string
  planId: string
  planName: string
  measure: string
  provider: string
  dueDate: string
  status: 'open' | 'closed'
}

export const STAR_TARGET = 4.5
export const MEASUREMENT_YEAR = 2026

export const PLANS: Plan[] = [
  { id: 'mmm', name: 'Medicare y Mucho Más (MMM)', members: 19800, open: 1300, closed: 2350, stars: 4.0, prevStars: 3.5 },
  { id: 'mcs', name: 'Medical Card System (MCS)', members: 15410, open: 1150, closed: 1980, stars: 4.5, prevStars: 4.0 },
  { id: 'triple-s', name: 'Triple-S', members: 13000, open: 1032, closed: 1587, stars: 3.5, prevStars: 3.5 },
]

export const GLOBAL_STARS = { stars: 4.0, prevStars: 3.5 }

const BASE_MEASURES: Measure[] = [
  { code: 'CBP', name: 'Control de presión arterial', weight: 3, rate: 68, threshold: 72, stars: 3 },
  { code: 'GSD', name: 'Evaluación glucémica en diabetes', weight: 3, rate: 79, threshold: 77, stars: 4 },
  { code: 'BCS', name: 'Cernimiento de cáncer de seno', weight: 1, rate: 74, threshold: 71, stars: 4 },
  { code: 'COL', name: 'Cernimiento de cáncer colorrectal', weight: 1, rate: 71, threshold: 73, stars: 3 },
  { code: 'EED', name: 'Examen de ojos en diabetes', weight: 1, rate: 76, threshold: 74, stars: 4 },
  { code: 'SPC', name: 'Estatinas en enfermedad cardiovascular', weight: 1, rate: 82, threshold: 80, stars: 4 },
  { code: 'KED', name: 'Evaluación renal en diabetes', weight: 1, rate: 66, threshold: 70, stars: 3 },
  { code: 'TRC', name: 'Transición de cuidado post-alta', weight: 1, rate: 59, threshold: 62, stars: 3 },
]

const PLAN_OFFSETS: Record<string, number> = {
  mmm: 1,
  mcs: 3,
  'triple-s': -4,
}

export function getMeasures(planId: string): Measure[] {
  if (planId === 'all') return BASE_MEASURES
  const offset = PLAN_OFFSETS[planId] ?? 0
  const starShift = offset >= 3 ? 1 : offset <= -3 ? -1 : 0
  return BASE_MEASURES.map((m) => ({
    ...m,
    rate: m.rate + offset,
    stars: Math.min(5, Math.max(1, m.stars + starShift)),
  }))
}

const gap = (
  n: number,
  memberName: string,
  memberId: string,
  planId: string,
  measure: string,
  provider: string,
  dueDate: string,
  status: CareGap['status'],
): CareGap => ({
  id: `g${n}`,
  memberName,
  memberId,
  planId,
  planName: PLANS.find((p) => p.id === planId)?.name ?? planId,
  measure,
  provider,
  dueDate,
  status,
})

export const SEED_GAPS: CareGap[] = [
  gap(1, 'Ana Torres', 'M-208311', 'mmm', 'BCS', 'Clínica San Rafael', '2026-11-15', 'open'),
  gap(2, 'Jorge Ramírez', 'M-208412', 'mcs', 'CBP', 'Dr. Héctor Lozano', '2026-10-30', 'open'),
  gap(3, 'María Castillo', 'M-209017', 'mmm', 'GSD', 'Centro Médico Norte', '2026-12-01', 'open'),
  gap(4, 'Luis Herrera', 'M-209233', 'triple-s', 'COL', 'Gastro Integral', '2026-11-20', 'open'),
  gap(5, 'Carmen Ortiz', 'M-209480', 'mcs', 'EED', 'Visión Clara', '2026-10-25', 'open'),
  gap(6, 'Roberto Silva', 'M-209551', 'mmm', 'SPC', 'Dr. Héctor Lozano', '2026-12-10', 'open'),
  gap(7, 'Patricia Vega', 'M-209702', 'triple-s', 'KED', 'Centro Médico Norte', '2026-11-05', 'open'),
  gap(8, 'Fernando Ruiz', 'M-209815', 'mmm', 'TRC', 'Hospital del Valle', '2026-10-18', 'open'),
  gap(9, 'Sofía Mendoza', 'M-210044', 'mcs', 'BCS', 'Clínica San Rafael', '2026-12-18', 'open'),
  gap(10, 'Diego Paredes', 'M-207120', 'mmm', 'CBP', 'Dr. Héctor Lozano', '2026-08-14', 'closed'),
  gap(11, 'Elena Navarro', 'M-207388', 'mcs', 'BCS', 'Clínica San Rafael', '2026-07-30', 'closed'),
  gap(12, 'Andrés Molina', 'M-207654', 'triple-s', 'GSD', 'Centro Médico Norte', '2026-09-02', 'closed'),
  gap(13, 'Rosa Fuentes', 'M-207911', 'mcs', 'COL', 'Gastro Integral', '2026-08-27', 'closed'),
  gap(14, 'Tomás Aguilar', 'M-208090', 'mmm', 'EED', 'Visión Clara', '2026-09-15', 'closed'),
  gap(15, 'Gloria Salazar', 'M-208177', 'triple-s', 'CBP', 'Dr. Héctor Lozano', '2026-06-21', 'closed'),
  gap(16, 'Hugo Cabrera', 'M-208260', 'triple-s', 'SPC', 'Centro Médico Norte', '2026-09-09', 'closed'),
]
