import 'server-only'
import { createSupabaseServerClient } from '@/lib/supabase/server'
import { SEED_GAPS } from './payer'
import { loadCareGaps, type CareGapsResult } from './care-gaps'

export type { DataSource } from './care-gaps'

export async function getCareGaps(): Promise<CareGapsResult> {
  try {
    return await loadCareGaps(createSupabaseServerClient())
  } catch (err) {
    const reason = err instanceof Error ? err.message : 'Error desconocido'
    return { gaps: SEED_GAPS, source: { kind: 'demo', reason } }
  }
}
