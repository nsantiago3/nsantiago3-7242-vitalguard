import type { SupabaseClient } from '@supabase/supabase-js'
import { PLANS, SEED_GAPS, type CareGap } from './payer'

export type DataSource = { kind: 'supabase' } | { kind: 'demo'; reason: string }
export type CareGapsResult = { gaps: CareGap[]; source: DataSource }

type Row = Record<string, unknown>

function pick(row: Row, ...keys: string[]) {
  for (const key of keys) {
    const value = row[key]
    if (value !== null && value !== undefined && value !== '') return String(value)
  }
  return ''
}

const CLOSED_STATUS = /^(closed|cerrad[ao]|complete[d]?|completad[ao])$/i

function mapRow(row: Row, index: number): CareGap {
  const planName = pick(row, 'plan_name', 'plan', 'health_plan')
  const plan = PLANS.find((p) => p.name === planName)
  const status = pick(row, 'status', 'state', 'gap_status').trim()
  return {
    id: pick(row, 'id', 'gap_id') || `row-${index}`,
    memberName: pick(row, 'member_name', 'member', 'patient_name', 'name') || 'Miembro sin nombre',
    memberId: pick(row, 'member_id', 'patient_id', 'member_code'),
    planId: plan?.id ?? pick(row, 'plan_id'),
    planName,
    measure: pick(row, 'measure_code', 'measure', 'hedis_measure').toUpperCase(),
    provider: pick(row, 'provider_name', 'provider'),
    dueDate: pick(row, 'due_date', 'due', 'deadline').slice(0, 10),
    status: CLOSED_STATUS.test(status) ? 'closed' : 'open',
  }
}

export async function loadCareGaps(supabase: SupabaseClient): Promise<CareGapsResult> {
  try {
    const { data, error } = await supabase.from('v_care_gaps').select('*').limit(500)

    if (error) {
      console.error('Error al cargar brechas de Supabase:', error)
      return { gaps: SEED_GAPS, source: { kind: 'demo', reason: error.message } }
    }
    if (!data || data.length === 0) {
      return { gaps: SEED_GAPS, source: { kind: 'demo', reason: 'La vista v_care_gaps no tiene filas visibles.' } }
    }
    return { gaps: (data as Row[]).map(mapRow), source: { kind: 'supabase' } }
  } catch (err) {
    console.error('Error inesperado al cargar brechas:', err)
    const reason = err instanceof Error ? err.message : 'Error desconocido'
    return { gaps: SEED_GAPS, source: { kind: 'demo', reason } }
  }
}
