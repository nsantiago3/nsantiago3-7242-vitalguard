const MONTHS_3 = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
const MONTHS_SHORT = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sept', 'oct', 'nov', 'dic']

function parts(iso: string) {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number)
  return { y, m, d }
}

export function formatDate(iso: string) {
  const { y, m, d } = parts(iso)
  return `${String(d).padStart(2, '0')} ${MONTHS_3[m - 1]} ${y}`
}

export function formatShort(iso: string) {
  const { m, d } = parts(iso)
  return `${d} ${MONTHS_SHORT[m - 1]}`
}

export function addDays(iso: string, days: number) {
  const { y, m, d } = parts(iso)
  const date = new Date(Date.UTC(y, m - 1, d + days))
  return date.toISOString().slice(0, 10)
}

export function formatNumber(value: number) {
  return String(Math.round(value)).replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}
