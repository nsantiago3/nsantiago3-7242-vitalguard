'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSupabaseBrowserClient } from '@/lib/supabase/client'

export default function AuthCallbackPage() {
  const router = useRouter()
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    const supabase = getSupabaseBrowserClient()
    const code = new URLSearchParams(window.location.search).get('code')

    async function finishSignIn() {
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code)
        if (error) {
          setFailed(true)
          return
        }
      } else {
        const { data } = await supabase.auth.getSession()
        if (!data.session) {
          setFailed(true)
          return
        }
      }
      router.replace('/')
    }

    finishSignIn()
  }, [router])

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 p-6">
      <div role="status" className="max-w-sm rounded-3xl border border-slate-200 bg-white p-8 text-center">
        {failed ? (
          <>
            <h1 className="text-lg font-semibold text-ink">No pudimos confirmar tu cuenta</h1>
            <p className="mt-2 text-sm text-slate-500">
              El enlace expiró o ya fue usado. Inicia sesión o crea la cuenta de nuevo.
            </p>
            <a href="/login" className="mt-5 inline-block text-sm font-medium text-brand hover:underline">
              Ir a iniciar sesión
            </a>
          </>
        ) : (
          <p className="text-sm text-slate-500">Confirmando tu cuenta…</p>
        )}
      </div>
    </main>
  )
}
