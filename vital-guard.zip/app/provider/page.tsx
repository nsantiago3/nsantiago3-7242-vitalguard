import { ActionTimeline } from '@/components/provider/action-timeline'
import { QueueHeader } from '@/components/provider/queue-header'
import { TaskQueue } from '@/components/provider/task-queue'

export default function ProviderPage() {
  return (
    <div className="flex flex-col gap-10">
      <QueueHeader />
      <ActionTimeline />
      <TaskQueue />
    </div>
  )
}
