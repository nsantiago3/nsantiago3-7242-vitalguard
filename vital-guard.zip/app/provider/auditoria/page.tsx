import { AuditLog } from '@/components/provider/audit-log'

export const metadata = { title: 'Auditoría | VitalGuard GPS Preventivo' }

export default function AuditPage() {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-4xl font-semibold tracking-tight">Auditoría</h1>
        <p className="mt-3 text-xl text-slate-500">Registro cronológico de cada decisión sobre una brecha preventiva.</p>
      </div>
      <AuditLog />
    </div>
  )
}
