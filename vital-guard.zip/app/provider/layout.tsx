import { IdleLogout } from '@/components/auth/idle-logout'
import { ProviderNav } from '@/components/provider/provider-nav'
import { ProviderStateProvider } from '@/components/provider/provider-state'

export const metadata = { title: 'Cola de acción | VitalGuard GPS Preventivo' }

export default function ProviderLayout({ children }: { children: React.ReactNode }) {
  return (
    <ProviderStateProvider>
      <div className="min-h-screen bg-p-canvas text-p-ink">
        <IdleLogout />
        <ProviderNav />
        <main className="mx-auto max-w-[1240px] px-6 py-10">{children}</main>
      </div>
    </ProviderStateProvider>
  )
}
