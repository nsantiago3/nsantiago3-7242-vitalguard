import { ClaimsUploader } from '@/components/payer/claims-uploader'

export const metadata = { title: 'Claims CSV | VitalGuard' }

export default function ClaimsPage() {
  return (
    <div className="mx-auto flex max-w-[1180px] flex-col gap-8">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-ink">Claims CSV</h1>
        <p className="mt-2 text-lg text-slate-500">Carga y valida archivos de reclamaciones antes de procesarlos.</p>
      </div>
      <ClaimsUploader />
    </div>
  )
}
