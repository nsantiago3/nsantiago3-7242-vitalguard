import { Dashboard } from '@/components/payer/dashboard'
import { getCareGaps } from '@/lib/data/queries'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const initial = await getCareGaps()
  return <Dashboard initial={initial} />
}
