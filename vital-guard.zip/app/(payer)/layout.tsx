import { IdleLogout } from '@/components/auth/idle-logout'
import { PayerSidebar } from '@/components/payer/sidebar'
import { PayerTopbar } from '@/components/payer/topbar'

export default function PayerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-canvas text-ink">
      <IdleLogout />
      <PayerSidebar />
      <div className="md:pl-64">
        <PayerTopbar />
        <main className="px-6 py-8 md:px-8">{children}</main>
      </div>
    </div>
  )
}
