import { LoginForm } from '@/components/payer/login-form'

export const metadata = { title: 'Login | VitalGuard' }

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ motivo?: string }>
}) {
  const { motivo } = await searchParams

  return (
    <div className="mx-auto flex max-w-md flex-col gap-6 pt-8">
      <div>
        <h1 className="text-3xl font-semibold tracking-tight text-ink">Acceso a VitalGuard</h1>
        <p className="mt-2 text-slate-500">Ingresa con tu cuenta corporativa del plan médico.</p>
      </div>
      {motivo === 'inactividad' && (
        <p role="status" className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          Tu sesión se cerró automáticamente tras 15 minutos de inactividad. Vuelve a ingresar para continuar.
        </p>
      )}
      <LoginForm />
    </div>
  )
}
