'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

const TABS = [
  { href: '/provider', label: 'Cola de acción' },
  { href: '/provider/auditoria', label: 'Auditoría' },
]

export function ProviderNav() {
  const pathname = usePathname()

  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-[1240px] items-center justify-between gap-4 px-6 py-4">
        <Link href="/provider" className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-xl bg-teal-deep" aria-hidden="true">
            <span className="h-4 w-0.5 rounded bg-white" />
            <span className="ml-1 h-2 w-0.5 rounded bg-white" />
          </span>
          <span className="flex flex-col">
            <span className="font-semibold leading-5 text-p-ink">VitalGuard</span>
            <span className="font-mono text-xs leading-4 text-slate-500">GPS Preventivo</span>
          </span>
        </Link>

        <nav aria-label="Principal" className="flex items-center gap-1">
          {TABS.map((tab) => {
            const active = pathname === tab.href
            return (
              <Link
                key={tab.href}
                href={tab.href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'rounded-xl px-4 py-2.5 text-base font-medium transition-colors',
                  active ? 'bg-teal-soft text-teal-deep' : 'text-slate-500 hover:text-p-ink',
                )}
              >
                {tab.label}
              </Link>
            )
          })}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden text-right lg:block">
            <p className="font-semibold leading-5 text-p-ink">Dra. Lucía Ramírez</p>
            <p className="text-sm leading-5 text-slate-500">Clínica Norte · Atención primaria</p>
          </div>
          <span
            aria-hidden="true"
            className="flex size-11 items-center justify-center rounded-full bg-teal-soft text-sm font-semibold text-teal-deep"
          >
            LR
          </span>
        </div>
      </div>
    </header>
  )
}
