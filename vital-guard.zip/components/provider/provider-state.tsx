'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { SEED_TASKS, type HistoryEvent, type Task } from '@/lib/data/provider'

type AuditEntry = HistoryEvent & { taskId: string; taskTitle: string; patient: string }

type ProviderState = {
  tasks: Task[]
  selectedId: string | null
  select: (id: string | null) => void
  schedule: (id: string) => void
  complete: (id: string) => void
  audit: AuditEntry[]
}

const ProviderContext = createContext<ProviderState | null>(null)

const ACTOR = 'Dra. Lucía Ramírez'

function timestamp() {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

export function ProviderStateProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(SEED_TASKS)
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const update = useCallback((id: string, status: Task['status'], action: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id
          ? { ...task, status, history: [...task.history, { at: timestamp(), actor: ACTOR, action }] }
          : task,
      ),
    )
  }, [])

  const schedule = useCallback((id: string) => update(id, 'scheduled', 'Cita agendada'), [update])
  const complete = useCallback((id: string) => update(id, 'closed', 'Tarea completada y brecha cerrada'), [update])

  const audit = useMemo<AuditEntry[]>(
    () =>
      tasks
        .flatMap((task) =>
          task.history.map((event) => ({ ...event, taskId: task.id, taskTitle: task.title, patient: task.patient })),
        )
        .sort((a, b) => b.at.localeCompare(a.at)),
    [tasks],
  )

  const value = useMemo(
    () => ({ tasks, selectedId, select: setSelectedId, schedule, complete, audit }),
    [tasks, selectedId, schedule, complete, audit],
  )

  return <ProviderContext.Provider value={value}>{children}</ProviderContext.Provider>
}

export function useProviderState() {
  const ctx = useContext(ProviderContext)
  if (!ctx) throw new Error('useProviderState debe usarse dentro de ProviderStateProvider')
  return ctx
}
