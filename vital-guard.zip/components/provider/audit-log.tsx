'use client'

import { useProviderState } from './provider-state'

export function AuditLog() {
  const { audit } = useProviderState()

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left">
          <thead className="bg-slate-50 font-mono text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th scope="col" className="px-6 py-4 font-medium">Fecha</th>
              <th scope="col" className="px-4 py-4 font-medium">Actor</th>
              <th scope="col" className="px-4 py-4 font-medium">Acción</th>
              <th scope="col" className="px-6 py-4 font-medium">Paciente · Tarea</th>
            </tr>
          </thead>
          <tbody>
            {audit.map((entry, i) => (
              <tr key={`${entry.taskId}-${i}`} className="border-t border-slate-200 align-top">
                <td className="whitespace-nowrap px-6 py-4 font-mono text-sm text-slate-500">{entry.at}</td>
                <td className="px-4 py-4 text-sm font-medium">{entry.actor}</td>
                <td className="px-4 py-4 text-sm">{entry.action}</td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {entry.patient} · {entry.taskTitle}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
