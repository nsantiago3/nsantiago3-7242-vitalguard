'use client'

import { useState } from 'react'
import { CalendarPlus, Check } from 'lucide-react'
import { useProviderState } from './provider-state'
import { TaskDetail } from './task-detail'
import { DEMO_TODAY, type Task } from '@/lib/data/provider'
import { addDays, formatShort } from '@/lib/format'
import { cn } from '@/lib/utils'

type TabId = 'act' | 'overdue' | 'week' | 'scheduled' | 'closed'

const FILTERS: Record<TabId, (t: Task) => boolean> = {
  act: (t) => t.status === 'pending',
  overdue: (t) => t.status === 'pending' && t.offset < 0,
  week: (t) => t.status === 'pending' && t.offset >= 0 && t.offset <= 7,
  scheduled: (t) => t.status === 'scheduled',
  closed: (t) => t.status === 'closed',
}

const TABS: { id: TabId; label: string }[] = [
  { id: 'act', label: 'Por actuar' },
  { id: 'overdue', label: 'Vencidas' },
  { id: 'week', label: 'Próximos 7 días' },
  { id: 'scheduled', label: 'Agendadas' },
  { id: 'closed', label: 'Cerradas' },
]

function dueLabel(task: Task) {
  if (task.status === 'closed') return { text: 'Completada', late: false }
  if (task.status === 'scheduled') return { text: `Agendada · ${formatShort(addDays(DEMO_TODAY, task.offset))}`, late: false }
  if (task.offset < 0) return { text: `Vencida hace ${Math.abs(task.offset)} d`, late: true }
  if (task.offset === 0) return { text: 'Vence hoy', late: false }
  return { text: `Vence en ${task.offset} d`, late: false }
}

export function TaskQueue() {
  const { tasks, selectedId, select, schedule, complete } = useProviderState()
  const [tab, setTab] = useState<TabId>('act')

  const list = tasks.filter(FILTERS[tab]).sort((a, b) => b.score - a.score)
  const selected = tasks.find((t) => t.id === selectedId) ?? null

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div>
        <div role="tablist" aria-label="Filtrar tareas" className="flex gap-6 overflow-x-auto border-b border-slate-200">
          {TABS.map((t) => {
            const count = tasks.filter(FILTERS[t.id]).length
            const active = tab === t.id
            return (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setTab(t.id)}
                className={cn(
                  '-mb-px flex shrink-0 items-center gap-2 border-b-2 px-1 py-3 text-base font-medium transition-colors',
                  active ? 'border-teal-deep text-p-ink' : 'border-transparent text-slate-500 hover:text-p-ink',
                )}
              >
                {t.label}
                <span
                  className={cn(
                    'rounded-md px-2 py-0.5 font-mono text-xs',
                    t.id === 'overdue' && count > 0 ? 'bg-late-soft text-late' : 'bg-slate-200/70 text-slate-500',
                  )}
                >
                  {count}
                </span>
              </button>
            )
          })}
        </div>

        <ul className="mt-4 overflow-hidden rounded-2xl border border-slate-200 bg-white">
          {list.length === 0 && <li className="px-6 py-12 text-center text-slate-500">No hay tareas en esta vista.</li>}
          {list.map((task) => {
            const due = dueLabel(task)
            const isSelected = selectedId === task.id
            return (
              <li
                key={task.id}
                className={cn('flex items-center gap-4 border-b border-slate-200 p-4 last:border-b-0', isSelected && 'bg-teal-soft/40')}
              >
                <button
                  type="button"
                  onClick={() => select(task.id)}
                  aria-pressed={isSelected}
                  className="flex min-w-0 flex-1 items-start gap-4 text-left focus-visible:outline-2 focus-visible:outline-teal-deep"
                >
                  <span
                    className={cn(
                      'flex h-10 w-14 shrink-0 items-center justify-center rounded-lg text-lg font-semibold text-white',
                      task.offset < 0 && task.status === 'pending' ? 'bg-late' : 'bg-p-ink',
                    )}
                  >
                    {task.score}
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold">{task.title}</span>
                    <span className="mt-0.5 block text-slate-500">
                      {task.patient} · {task.age} a · {task.measure}
                    </span>
                    <span className="mt-0.5 flex flex-wrap items-center gap-x-3 text-sm">
                      <span className={cn('font-mono font-semibold', due.late ? 'text-late' : 'text-p-ink')}>{due.text}</span>
                      <span className="text-slate-500">Evidencia: {task.evidence}</span>
                    </span>
                    <span className="mt-0.5 block text-sm text-slate-500">{task.owner}</span>
                  </span>
                </button>
                {task.status !== 'closed' && (
                  <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
                    <button
                      type="button"
                      onClick={() => schedule(task.id)}
                      disabled={task.status === 'scheduled'}
                      className="flex h-11 items-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-4 text-sm font-medium transition-colors hover:bg-slate-100 disabled:opacity-50"
                    >
                      <CalendarPlus className="size-4" aria-hidden="true" />
                      Agendar
                    </button>
                    <button
                      type="button"
                      onClick={() => complete(task.id)}
                      className="flex h-11 items-center gap-2 rounded-lg bg-teal-deep px-4 text-sm font-medium text-white transition-colors hover:bg-teal-deep/90"
                    >
                      <Check className="size-4" aria-hidden="true" />
                      Completar
                    </button>
                  </div>
                )}
              </li>
            )
          })}
        </ul>
      </div>

      <aside aria-label="Detalle de la tarea" className="lg:sticky lg:top-6">
        {selected ? (
          <TaskDetail task={selected} />
        ) : (
          <p className="rounded-2xl border border-dashed border-teal-deep/40 p-6 text-lg leading-8 text-slate-500">
            Selecciona una tarea de la cola o un punto en la pista para ver la evidencia, el motivo de la prioridad y el
            historial auditable.
          </p>
        )}
      </aside>
    </div>
  )
}
