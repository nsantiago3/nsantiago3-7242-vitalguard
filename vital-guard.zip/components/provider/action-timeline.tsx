'use client'

import { useProviderState } from './provider-state'
import { DEMO_TODAY } from '@/lib/data/provider'
import { addDays, formatShort } from '@/lib/format'
import { cn } from '@/lib/utils'

const RANGE_START = -21
const RANGE_END = 28
const SPAN = RANGE_END - RANGE_START
const TICKS = [-21, -14, -7, 0, 7, 14, 21, 28]

const pct = (offset: number) => ((offset - RANGE_START) / SPAN) * 100

function tickLabel(offset: number) {
  if (offset === 0) return 'HOY'
  return `${offset > 0 ? '+' : '-'}${Math.abs(offset)}d`
}

export function ActionTimeline() {
  const { tasks, selectedId, select } = useProviderState()
  const visible = tasks.filter((t) => t.status !== 'closed')

  return (
    <section aria-labelledby="timeline-title" className="rounded-2xl border border-slate-200 bg-white p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="timeline-title" className="text-lg font-semibold">
          Pista de fechas de acción
        </h2>
        <ul className="flex items-center gap-5 text-sm text-slate-500">
          <li className="flex items-center gap-2">
            <span className="size-3 rounded-full bg-late" aria-hidden="true" />
            Vencida
          </li>
          <li className="flex items-center gap-2">
            <span className="size-3 rounded-full bg-p-ink" aria-hidden="true" />
            Por vencer
          </li>
          <li className="flex items-center gap-2">
            <span className="size-3 rounded-full border-2 border-teal-deep" aria-hidden="true" />
            Agendada
          </li>
        </ul>
      </div>

      <div className="mt-6 overflow-x-auto">
        <div className="min-w-[640px] px-3 pb-1">
          <div className="relative h-44 border-b border-slate-300">
            <div
              className="absolute inset-y-0 left-0 bg-late-soft"
              style={{ width: `${pct(0)}%` }}
              aria-hidden="true"
            />
            {TICKS.map((tick) => (
              <span
                key={tick}
                aria-hidden="true"
                className={cn('absolute inset-y-0 w-px', tick === 0 ? 'bg-p-ink' : 'bg-slate-200')}
                style={{ left: `${pct(tick)}%` }}
              />
            ))}
            {visible.map((task) => {
              const overdue = task.status === 'pending' && task.offset < 0
              const scheduled = task.status === 'scheduled'
              const selected = selectedId === task.id
              return (
                <button
                  key={task.id}
                  type="button"
                  onClick={() => select(task.id)}
                  aria-label={`${task.title}, ${task.patient}, ${formatShort(addDays(DEMO_TODAY, task.offset))}`}
                  aria-pressed={selected}
                  className="absolute bottom-0 flex size-7 -translate-x-1/2 translate-y-1/2 items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-teal-deep"
                  style={{ left: `${pct(task.offset)}%`, bottom: 28 }}
                >
                  <span
                    className={cn(
                      'block size-3.5 rounded-full transition-transform',
                      overdue && 'bg-late',
                      scheduled && 'border-2 border-teal-deep bg-white',
                      !overdue && !scheduled && 'bg-p-ink',
                      selected && 'scale-125 ring-2 ring-teal-deep ring-offset-2',
                    )}
                  />
                </button>
              )
            })}
          </div>
          <div className="relative mt-3 h-12">
            {TICKS.map((tick) => (
              <div
                key={tick}
                className={cn(
                  'absolute top-0 -translate-x-1/2 whitespace-nowrap text-center font-mono text-sm leading-5',
                  tick === 0 ? 'font-semibold text-p-ink' : 'text-slate-500',
                  tick === RANGE_START && 'translate-x-0 text-left',
                  tick === RANGE_END && '-translate-x-full text-right',
                )}
                style={{ left: `${pct(tick)}%` }}
              >
                <p>{tickLabel(tick)}</p>
                <p>{formatShort(addDays(DEMO_TODAY, tick))}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
