'use client'

import { useProviderState } from './provider-state'
import { DEMO_TODAY } from '@/lib/data/provider'
import { formatShort } from '@/lib/format'

export function QueueHeader() {
  const { tasks } = useProviderState()
  const pending = tasks.filter((t) => t.status === 'pending')
  const overdue = pending.filter((t) => t.offset < 0).length
  const week = pending.filter((t) => t.offset >= 0 && t.offset <= 7).length
  const year = DEMO_TODAY.slice(0, 4)

  return (
    <div>
      <p className="font-mono text-sm uppercase tracking-widest text-slate-500">
        {formatShort(DEMO_TODAY)} {year}
      </p>
      <h1 className="mt-3 text-4xl font-semibold tracking-tight text-balance md:text-5xl">De la brecha a la fecha de acción</h1>
      <p className="mt-4 max-w-3xl text-xl leading-9 text-slate-500 text-pretty">
        {overdue} brechas preventivas ya pasaron su fecha y {week} vencen esta semana. Empieza por la prioridad más alta.
      </p>
    </div>
  )
}
