import type { Task } from '@/lib/data/provider'

export function TaskDetail({ task }: { task: Task }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6">
      <p className="font-mono text-xs uppercase tracking-wide text-slate-500">{task.measure}</p>
      <h3 className="mt-1 text-lg font-semibold">{task.title}</h3>
      <p className="mt-1 text-slate-500">
        {task.patient} · {task.age} a
      </p>

      <dl className="mt-5 space-y-4 text-sm">
        <div>
          <dt className="font-medium text-slate-500">Motivo de la prioridad ({task.score})</dt>
          <dd className="mt-1 leading-6">{task.reason}</dd>
        </div>
        <div>
          <dt className="font-medium text-slate-500">Evidencia</dt>
          <dd className="mt-1">{task.evidence}</dd>
        </div>
        <div>
          <dt className="font-medium text-slate-500">Responsable</dt>
          <dd className="mt-1">{task.owner}</dd>
        </div>
      </dl>

      <h4 className="mt-6 text-sm font-medium text-slate-500">Historial auditable</h4>
      <ol className="mt-3 space-y-3 border-l border-slate-200 pl-4">
        {task.history.map((event, i) => (
          <li key={i} className="relative text-sm">
            <span className="absolute -left-[21px] top-1.5 size-2 rounded-full bg-teal-deep" aria-hidden="true" />
            <p className="font-mono text-xs text-slate-500">
              {event.at} · {event.actor}
            </p>
            <p className="mt-0.5 leading-5">{event.action}</p>
          </li>
        ))}
      </ol>
    </div>
  )
}
