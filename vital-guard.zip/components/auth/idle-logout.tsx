'use client'

import { useAutoLogout } from '@/lib/hooks/use-auto-logout'

export function IdleLogout() {
  useAutoLogout()
  return null
}
