'use client'

import { useMemo, useState } from 'react'
import { Search } from 'lucide-react'
import type { CareGap } from '@/lib/data/payer'
import { formatDate } from '@/lib/format'
import { cn } from '@/lib/utils'

type Filter = 'all' | 'open' | 'closed'

export function CareGapsTable({ gaps }: { gaps: CareGap[] }) {
  const [filter, setFilter] = useState<Filter>('all')
  const [query, setQuery] = useState('')

  const counts = useMemo(
    () => ({
      all: gaps.length,
      open: gaps.filter((g) => g.status === 'open').length,
      closed: gaps.filter((g) => g.status === 'closed').length,
    }),
    [gaps],
  )

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return gaps.filter((g) => {
      if (filter !== 'all' && g.status !== filter) return false
      if (!q) return true
      return [g.memberName, g.memberId, g.measure, g.provider, g.planName].some((v) => v.toLowerCase().includes(q))
    })
  }, [gaps, filter, query])

  const tabs: { id: Filter; label: string }[] = [
    { id: 'all', label: 'Todas' },
    { id: 'open', label: 'Open' },
    { id: 'closed', label: 'Closed' },
  ]

  return (
    <section aria-labelledby="gaps-title" className="overflow-hidden rounded-3xl border border-slate-200 bg-white">
      <div className="flex flex-col gap-4 p-6 xl:flex-row xl:items-center xl:justify-between">
        <div className="min-w-0">
          <h2 id="gaps-title" className="text-xl font-semibold text-ink">
            Brechas de cuidado
          </h2>
          <p className="mt-1 text-slate-500">Actividad reciente por miembro y medida.</p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div role="tablist" aria-label="Filtrar por estado" className="flex rounded-2xl bg-slate-100 p-1">
            {tabs.map((tab) => {
              const selected = filter === tab.id
              return (
                <button
                  key={tab.id}
                  role="tab"
                  type="button"
                  aria-selected={selected}
                  onClick={() => setFilter(tab.id)}
                  className={cn(
                    'flex min-w-20 flex-col items-center rounded-xl px-4 py-2 text-sm font-medium leading-5 transition-colors',
                    selected ? 'bg-white text-ink shadow-sm' : 'text-slate-500 hover:text-ink',
                  )}
                >
                  {tab.label}
                  <span className="text-xs font-normal">{counts[tab.id]}</span>
                </button>
              )
            })}
          </div>
          <label className="relative block">
            <span className="sr-only">Buscar por miembro, medida o proveedor</span>
            <Search className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Miembro, medida o proveedor"
              className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm text-ink placeholder:text-slate-400 focus-visible:outline-2 focus-visible:outline-brand sm:w-72"
            />
          </label>
        </div>
      </div>

      <div className="overflow-x-auto border-t border-slate-200">
        <table className="w-full min-w-[820px] text-left">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th scope="col" className="px-6 py-4 font-medium">Miembro</th>
              <th scope="col" className="px-4 py-4 font-medium">Plan</th>
              <th scope="col" className="px-4 py-4 font-medium">Medida</th>
              <th scope="col" className="px-4 py-4 font-medium">Proveedor</th>
              <th scope="col" className="px-4 py-4 font-medium">Vence</th>
              <th scope="col" className="px-6 py-4 font-medium">Estado</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((g) => (
              <tr key={g.id} className="border-t border-slate-200">
                <td className="px-6 py-5">
                  <p className="max-w-28 font-medium leading-6 text-ink">{g.memberName}</p>
                  <p className="font-mono text-sm text-slate-500">{g.memberId}</p>
                </td>
                <td className="px-4 py-5 text-slate-500">{g.planName}</td>
                <td className="px-4 py-5">
                  <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-sm font-bold text-ink">{g.measure}</span>
                </td>
                <td className="px-4 py-5 text-slate-500">{g.provider}</td>
                <td className="whitespace-nowrap px-4 py-5 font-medium text-ink">{g.dueDate ? formatDate(g.dueDate) : '—'}</td>
                <td className="px-6 py-5">
                  <span
                    className={cn(
                      'rounded-full px-3 py-1 text-xs font-semibold',
                      g.status === 'open' ? 'bg-bad-soft text-bad' : 'bg-ok-soft text-ok',
                    )}
                  >
                    {g.status === 'open' ? 'Open' : 'Closed'}
                  </span>
                </td>
              </tr>
            ))}
            {visible.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                  No hay brechas que coincidan con el filtro.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  )
}
