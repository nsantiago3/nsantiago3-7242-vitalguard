'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSupabaseBrowserClient } from '@/lib/supabase/client'
import { getAuthCallbackUrl } from '@/lib/auth-redirect'

export function LoginForm() {
  const router = useRouter()
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [pending, setPending] = useState(false)
  const [message, setMessage] = useState<{ type: 'error' | 'info'; text: string } | null>(null)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setPending(true)
    setMessage(null)
    const supabase = getSupabaseBrowserClient()

    if (mode === 'signin') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setMessage({ type: 'error', text: error.message })
      else router.push('/')
    } else {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: getAuthCallbackUrl() },
      })
      if (error) setMessage({ type: 'error', text: error.message })
      else if (data.session) router.push('/')
      else setMessage({ type: 'info', text: 'Revisa tu correo para confirmar la cuenta.' })
    }
    setPending(false)
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-5 rounded-3xl border border-slate-200 bg-white p-8">
      <div>
        <label htmlFor="email" className="mb-2 block text-sm font-medium text-ink">
          Correo electrónico
        </label>
        <input
          id="email"
          type="email"
          required
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-12 w-full rounded-xl border border-slate-200 px-4 text-ink focus-visible:outline-2 focus-visible:outline-brand"
        />
      </div>
      <div>
        <label htmlFor="password" className="mb-2 block text-sm font-medium text-ink">
          Contraseña
        </label>
        <input
          id="password"
          type="password"
          required
          minLength={6}
          autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="h-12 w-full rounded-xl border border-slate-200 px-4 text-ink focus-visible:outline-2 focus-visible:outline-brand"
        />
      </div>

      {message && (
        <p
          role={message.type === 'error' ? 'alert' : 'status'}
          className={message.type === 'error' ? 'text-sm text-bad' : 'text-sm text-ok'}
        >
          {message.text}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="h-12 rounded-xl bg-navy font-medium text-white transition-colors hover:bg-navy-active disabled:opacity-60"
      >
        {pending ? 'Procesando…' : mode === 'signin' ? 'Iniciar sesión' : 'Crear cuenta'}
      </button>
      <button
        type="button"
        onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
        className="text-sm text-brand hover:underline"
      >
        {mode === 'signin' ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
      </button>
    </form>
  )
}
