'use client'

import { useRef, useState } from 'react'
import { CircleAlert, CircleCheck, FileUp } from 'lucide-react'
import { cn } from '@/lib/utils'

const REQUIRED_COLUMNS = ['claim_id', 'member_id', 'plan', 'measure', 'provider', 'service_date']
const PREVIEW_ROWS = 8

type Parsed = {
  fileName: string
  headers: string[]
  rows: string[][]
  totalRows: number
}

function parseLine(line: string) {
  const cells: string[] = []
  let current = ''
  let quoted = false
  for (let i = 0; i < line.length; i++) {
    const ch = line[i]
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        current += '"'
        i++
      } else {
        quoted = !quoted
      }
    } else if (ch === ',' && !quoted) {
      cells.push(current.trim())
      current = ''
    } else {
      current += ch
    }
  }
  cells.push(current.trim())
  return cells
}

function parseCsv(text: string, fileName: string): Parsed {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0)
  const [head = '', ...body] = lines
  return {
    fileName,
    headers: parseLine(head).map((h) => h.toLowerCase()),
    rows: body.slice(0, PREVIEW_ROWS).map(parseLine),
    totalRows: body.length,
  }
}

export function ClaimsUploader() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [parsed, setParsed] = useState<Parsed | null>(null)
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleFile(file: File | undefined) {
    if (!file) return
    if (!file.name.toLowerCase().endsWith('.csv')) {
      setError('El archivo debe tener formato .csv')
      setParsed(null)
      return
    }
    setError(null)
    setParsed(parseCsv(await file.text(), file.name))
  }

  const missing = parsed ? REQUIRED_COLUMNS.filter((c) => !parsed.headers.includes(c)) : []

  return (
    <div className="flex flex-col gap-6">
      <div
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          handleFile(e.dataTransfer.files[0])
        }}
        className={cn(
          'flex flex-col items-center gap-4 rounded-3xl border-2 border-dashed bg-white px-6 py-14 text-center transition-colors',
          dragging ? 'border-brand bg-brand-soft' : 'border-slate-300',
        )}
      >
        <span className="flex size-14 items-center justify-center rounded-2xl bg-brand-soft text-brand">
          <FileUp className="size-6" aria-hidden="true" />
        </span>
        <div>
          <p className="text-lg font-semibold text-ink">Arrastra tu archivo de reclamaciones</p>
          <p className="mt-1 text-sm text-slate-500">
            CSV con columnas: <span className="font-mono">{REQUIRED_COLUMNS.join(', ')}</span>
          </p>
        </div>
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="h-11 rounded-xl bg-navy px-5 text-sm font-medium text-white transition-colors hover:bg-navy-active"
        >
          Seleccionar archivo
        </button>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="sr-only"
          aria-label="Seleccionar archivo CSV"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      </div>

      {error && (
        <p role="alert" className="flex items-center gap-2 rounded-2xl bg-bad-soft px-4 py-3 text-sm text-bad">
          <CircleAlert className="size-4" aria-hidden="true" />
          {error}
        </p>
      )}

      {parsed && (
        <section aria-labelledby="preview-title" className="overflow-hidden rounded-3xl border border-slate-200 bg-white">
          <div className="flex flex-col gap-3 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 id="preview-title" className="text-xl font-semibold text-ink">
                {parsed.fileName}
              </h2>
              <p className="mt-1 text-slate-500">{parsed.totalRows} filas detectadas</p>
            </div>
            {missing.length === 0 ? (
              <p className="flex items-center gap-2 rounded-full bg-ok-soft px-4 py-2 text-sm font-semibold text-ok">
                <CircleCheck className="size-4" aria-hidden="true" />
                Estructura válida
              </p>
            ) : (
              <p className="flex items-center gap-2 rounded-full bg-bad-soft px-4 py-2 text-sm font-semibold text-bad">
                <CircleAlert className="size-4" aria-hidden="true" />
                Faltan columnas: {missing.join(', ')}
              </p>
            )}
          </div>
          <div className="overflow-x-auto border-t border-slate-200">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  {parsed.headers.map((h) => (
                    <th key={h} scope="col" className="px-4 py-3 font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {parsed.rows.map((row, i) => (
                  <tr key={i} className="border-t border-slate-200">
                    {row.map((cell, j) => (
                      <td key={j} className="px-4 py-3 text-ink">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  )
}
