import { Stars } from './stars'
import type { Measure } from '@/lib/data/payer'
import { cn } from '@/lib/utils'

function MeasureCell({ measure }: { measure: Measure }) {
  const above = measure.rate >= measure.threshold
  return (
    <li className="border-t border-slate-200 p-6 lg:odd:border-r">
      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-sm font-bold text-ink">{measure.code}</span>
          <span className="truncate font-medium text-ink">{measure.name}</span>
          {measure.weight > 1 && <span className="shrink-0 text-sm text-slate-400">×{measure.weight}</span>}
        </div>
        <Stars value={measure.stars} size={18} emptyClassName="text-slate-300" />
      </div>
      <div className="mt-4 flex items-center gap-4">
        <div
          className="relative h-2.5 flex-1 rounded-full bg-slate-100"
          role="img"
          aria-label={`${measure.rate}% de cumplimiento frente a umbral de ${measure.threshold}%`}
        >
          <div
            className={cn('h-full rounded-full', above ? 'bg-ok' : 'bg-gold')}
            style={{ width: `${measure.rate}%` }}
          />
          <span
            className="absolute -top-1 h-[18px] w-0.5 bg-ink"
            style={{ left: `${measure.threshold}%` }}
            aria-hidden="true"
          />
        </div>
        <p className="w-24 shrink-0 text-right text-sm tabular-nums">
          <span className="font-semibold text-ink">{measure.rate}%</span>
          <span className="text-slate-500"> / {measure.threshold}%</span>
        </p>
      </div>
    </li>
  )
}

export function MeasuresPanel({ measures }: { measures: Measure[] }) {
  return (
    <section aria-labelledby="measures-title" className="overflow-hidden rounded-3xl border border-slate-200 bg-white">
      <div className="flex flex-col gap-4 p-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 id="measures-title" className="text-xl font-semibold text-ink">
            Star Ratings por medida
          </h2>
          <p className="mt-1 text-slate-500">Tasa de cumplimiento frente al umbral de 4 estrellas.</p>
        </div>
        <ul className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-slate-500">
          <li className="flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-ok" aria-hidden="true" />
            Sobre umbral
          </li>
          <li className="flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-gold" aria-hidden="true" />
            Bajo umbral
          </li>
          <li className="flex items-center gap-2">
            <span className="h-3.5 w-0.5 bg-ink" aria-hidden="true" />
            Umbral 4 estrellas
          </li>
        </ul>
      </div>
      <ul className="grid lg:grid-cols-2">
        {measures.map((m) => (
          <MeasureCell key={m.code} measure={m} />
        ))}
      </ul>
    </section>
  )
}
