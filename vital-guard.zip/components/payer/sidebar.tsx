'use client'

import Image from 'next/image'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { FileUp, LayoutDashboard, LogIn, Stethoscope } from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/login', label: 'Login', icon: LogIn },
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/claims', label: 'Claims CSV', icon: FileUp },
]

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="VitalGuard, inicio">
      <Image
        src="/vitalguard-mark.png"
        alt=""
        width={56}
        height={56}
        className="size-12 rounded-xl object-cover md:size-14"
      />
      <span className="flex flex-col">
        <span className="text-2xl font-semibold leading-none tracking-tight text-white">
          Vital<span className="text-[#5fd0e0]">Guard</span>
        </span>
        <span className="mt-2 text-[10px] font-medium uppercase leading-3 tracking-[0.3em] text-white/50">
          Preventive
          <br />
          Intelligence
        </span>
      </span>
    </Link>
  )
}

export function PayerSidebar() {
  const pathname = usePathname()

  return (
    <>
      <aside className="fixed inset-y-0 left-0 hidden w-64 flex-col bg-navy px-4 py-8 md:flex">
        <div className="px-3">
          <Brand />
        </div>
        <nav aria-label="Principal" className="mt-12 flex flex-col gap-2">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'flex items-center gap-3 rounded-xl px-3 py-3 text-base font-medium transition-colors',
                  active ? 'bg-navy-active text-white' : 'text-white/70 hover:bg-white/5 hover:text-white',
                )}
              >
                <Icon className="size-5" aria-hidden="true" />
                {label}
              </Link>
            )
          })}
        </nav>
        <Link
          href="/provider"
          className="mt-auto flex items-center gap-3 rounded-xl border border-white/10 px-3 py-3 text-sm font-medium text-white/70 transition-colors hover:bg-white/5 hover:text-white"
        >
          <Stethoscope className="size-5" aria-hidden="true" />
          Portal de proveedores
        </Link>
      </aside>

      <header className="bg-navy px-4 py-4 md:hidden">
        <Brand />
        <nav aria-label="Principal" className="mt-4 flex gap-2 overflow-x-auto">
          {NAV.map(({ href, label }) => {
            const active = pathname === href
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium',
                  active ? 'bg-navy-active text-white' : 'text-white/70',
                )}
              >
                {label}
              </Link>
            )
          })}
          <Link href="/provider" className="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-white/70">
            Portal de proveedores
          </Link>
        </nav>
      </header>
    </>
  )
}
