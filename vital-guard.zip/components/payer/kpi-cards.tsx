import { CircleAlert, CircleCheck, Percent } from 'lucide-react'
import { Stars } from './stars'
import { formatNumber } from '@/lib/format'

type KpiCardsProps = {
  stars: number
  prevStars: number
  target: number
  open: number
  closed: number
  members: number
}

function formatDelta(delta: number) {
  if (delta === 0) return 'Sin cambio'
  return `${delta > 0 ? '+' : '−'}${Math.abs(delta).toFixed(1)}`
}

export function KpiCards({ stars, prevStars, target, open, closed, members }: KpiCardsProps) {
  const closeRate = Math.round((closed / (open + closed)) * 100)

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <section aria-label="Star Rating global" className="rounded-3xl bg-navy p-6 text-white">
        <h2 className="text-base text-white/70">Star Rating global</h2>
        <div className="mt-5 flex items-center gap-3">
          <span className="text-5xl font-semibold tracking-tight">{stars.toFixed(1)}</span>
          <Stars value={stars} size={26} emptyClassName="text-white/80" />
        </div>
        <p className="mt-4 text-sm text-white/70">
          {formatDelta(stars - prevStars)} vs. año anterior · Meta {target.toFixed(1)}
        </p>
      </section>

      <section aria-label="Brechas abiertas" className="rounded-3xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <h2 className="text-base text-slate-500">Brechas abiertas</h2>
          <span className="flex size-11 items-center justify-center rounded-xl bg-bad-soft text-bad">
            <CircleAlert className="size-5" aria-hidden="true" />
          </span>
        </div>
        <p className="mt-4 text-5xl font-semibold tracking-tight">{open}</p>
        <p className="mt-4 text-sm text-slate-500">Requieren acción</p>
      </section>

      <section aria-label="Brechas cerradas" className="rounded-3xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <h2 className="text-base text-slate-500">Brechas cerradas</h2>
          <span className="flex size-11 items-center justify-center rounded-xl bg-ok-soft text-ok">
            <CircleCheck className="size-5" aria-hidden="true" />
          </span>
        </div>
        <p className="mt-4 text-5xl font-semibold tracking-tight">{closed}</p>
        <p className="mt-4 text-sm text-slate-500">Año en curso</p>
      </section>

      <section aria-label="Tasa de cierre" className="rounded-3xl border border-slate-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <h2 className="text-base text-slate-500">Tasa de cierre</h2>
          <span className="flex size-11 items-center justify-center rounded-xl bg-brand-soft text-brand">
            <Percent className="size-5" aria-hidden="true" />
          </span>
        </div>
        <p className="mt-4 text-5xl font-semibold tracking-tight">{closeRate}%</p>
        <p className="mt-4 text-sm text-slate-500">{formatNumber(members)} miembros en alcance</p>
      </section>
    </div>
  )
}
