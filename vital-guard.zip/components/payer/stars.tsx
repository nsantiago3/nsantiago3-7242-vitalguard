import { Star } from 'lucide-react'

type StarsProps = {
  value: number
  size?: number
  emptyClassName?: string
}

export function Stars({ value, size = 16, emptyClassName = 'text-slate-300' }: StarsProps) {
  return (
    <span role="img" aria-label={`${value.toFixed(1)} de 5 estrellas`} className="inline-flex items-center gap-0.5">
      {[0, 1, 2, 3, 4].map((i) => {
        const fraction = Math.min(1, Math.max(0, value - i))
        return (
          <span key={i} className="relative inline-flex" style={{ width: size, height: size }}>
            <Star width={size} height={size} strokeWidth={1.75} className={emptyClassName} aria-hidden="true" />
            <span className="absolute inset-y-0 left-0 overflow-hidden" style={{ width: `${fraction * 100}%` }}>
              <Star
                width={size}
                height={size}
                strokeWidth={1.75}
                className="max-w-none text-gold"
                fill="currentColor"
                aria-hidden="true"
              />
            </span>
          </span>
        )
      })}
    </span>
  )
}
