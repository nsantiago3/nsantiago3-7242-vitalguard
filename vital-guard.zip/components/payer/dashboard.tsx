'use client'

import { useMemo, useState } from 'react'
import { Building2, ChevronDown } from 'lucide-react'
import {
  GLOBAL_STARS,
  MEASUREMENT_YEAR,
  PLANS,
  STAR_TARGET,
  getMeasures,
  type CareGap,
} from '@/lib/data/payer'
import type { CareGapsResult } from '@/lib/data/care-gaps'
import { useCareGaps } from '@/lib/hooks/use-care-gaps'
import { CareGapsTable } from './care-gaps-table'
import { KpiCards } from './kpi-cards'
import { MeasuresPanel } from './measures-panel'

export function Dashboard({ initial }: { initial: CareGapsResult }) {
  const { gaps, source } = useCareGaps(initial)
  const [planId, setPlanId] = useState('all')
  const plan = PLANS.find((p) => p.id === planId)

  const totals = useMemo(() => {
    if (plan) {
      return { stars: plan.stars, prevStars: plan.prevStars, open: plan.open, closed: plan.closed, members: plan.members }
    }
    return {
      ...GLOBAL_STARS,
      open: PLANS.reduce((sum, p) => sum + p.open, 0),
      closed: PLANS.reduce((sum, p) => sum + p.closed, 0),
      members: PLANS.reduce((sum, p) => sum + p.members, 0),
    }
  }, [plan])

  const visibleGaps = useMemo(
    () => (plan ? gaps.filter((g) => g.planId === plan.id || g.planName === plan.name) : gaps),
    [gaps, plan],
  )

  return (
    <div className="mx-auto flex max-w-[1180px] flex-col gap-8">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-ink">Dashboard HEDIS</h1>
          <p className="mt-2 text-lg text-slate-500">
            {plan ? plan.name : `Consolidado de ${PLANS.length} planes médicos`} · Año de medición {MEASUREMENT_YEAR}
          </p>
        </div>
        <div className="w-full lg:w-80">
          <label htmlFor="plan-select" className="mb-2 block text-sm text-slate-500">
            Plan médico
          </label>
          <div className="relative">
            <Building2 className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-slate-500" aria-hidden="true" />
            <select
              id="plan-select"
              value={planId}
              onChange={(e) => setPlanId(e.target.value)}
              className="h-14 w-full appearance-none rounded-2xl border border-slate-200 bg-white pl-12 pr-12 font-medium text-ink focus-visible:outline-2 focus-visible:outline-brand"
            >
              <option value="all">Todos los planes ({PLANS.length})</option>
              {PLANS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-4 top-1/2 size-5 -translate-y-1/2 text-slate-500" aria-hidden="true" />
          </div>
        </div>
      </div>

      <KpiCards {...totals} target={STAR_TARGET} />
      <MeasuresPanel measures={getMeasures(planId)} />
      <CareGapsTable key={planId} gaps={visibleGaps} />

      <p className="text-xs text-slate-500">
        {source.kind === 'supabase'
          ? 'Brechas de cuidado leídas desde Supabase (vista v_care_gaps).'
          : 'Mostrando brechas de demostración: no se pudieron leer datos reales de v_care_gaps. Inicia sesión para cargar los datos de tu cuenta.'}
      </p>
    </div>
  )
}
